window.addEventListener('resize', resizeSvg);

function resizeSvg(){
    let bbox = svg.getBoundingClientRect();
    svg.setAttribute("viewBox", `0 0 ${bbox.width} ${bbox.height}`);
    
    for(let ellipse of svg.children){
        ellipse.setAttribute('rx',  Math.min(bbox.width, bbox.height) * 0.1);
        ellipse.setAttribute('ry',  Math.min(bbox.width, bbox.height) * 0.1);

    }

    for(let rectangle of svg.children){
        rectangle.setAttribute('width',  Math.min(bbox.width, bbox.height) * 0.1);
        rectangle.setAttribute('height',  Math.min(bbox.width, bbox.height) * 0.1);

    }
}

// function randomNumber(range){
//     return Math.random()*range
// }


// function makeRGB(redInput, greenInput, blueInput){
//     let redOutput = redInput ?? randomNumber(255);
//     let greenOutput = greenInput ?? randomNumber(255);
//     let blueOutput = blueInput ?? randomNumber(255);
//     return `rgb(${redOutput}, ${greenOutput}, ${blueOutput})`;
// }

// let svg = document.getElementById("basesvg");

// let width = 1000;
// let height = 1000;

// svg.setAttribute("width", width);
// svg.setAttribute("height", height);

// function makeRect(x, y, w, h, r, g, b){
//     let xPos = x ?? randomNumber(width);
//     let yPos = y ?? randomNumber(height);
//     let rectWidth = w ?? randomNumber(width);
//     let rectHeight = h ?? randomNumber(height);
//     let colour = makeRGB(r, g, b);
    

//     let rect1 = document.createElementNS("http://www.w3.org/2000/svg", "rect"); 
//     console.log(rect1);  

//     rect1.setAttribute("x", xPos);
//     rect1.setAttribute("y", yPos);
//     rect1.setAttribute("height", rectHeight);
//     rect1.setAttribute("width", rectWidth);
//     rect1.setAttribute("fill", colour);

//     svg.appendChild(rect1);
// }
